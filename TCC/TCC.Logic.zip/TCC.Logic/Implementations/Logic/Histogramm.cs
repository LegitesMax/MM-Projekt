﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TCC.Logic.Implementations.Logic
{
    public class Histogramm
    {
        public char? Character { get; set; }
        public int Count { get; set; }
    }
}
