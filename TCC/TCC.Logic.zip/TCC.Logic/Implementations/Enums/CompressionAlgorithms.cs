﻿namespace TCC.Logic.Implementations.Enums
{
    public enum CompressionAlgorithms
    {
        Huffman, RLE
    }
}
