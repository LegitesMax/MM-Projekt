﻿namespace TCC.Logic.Implementations.Enums
{
    public enum EncryptionAlgorithms
    {
         Caesar,
        /*...
         */
    }
}
